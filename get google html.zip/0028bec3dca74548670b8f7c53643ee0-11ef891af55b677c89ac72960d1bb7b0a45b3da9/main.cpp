#include <winsock2.h>
#include <windows.h>
#include <iostream>
using namespace std;

#pragma warning (disable:4996)
#pragma comment(lib,"ws2_32.lib")

int main()
{
    system("title HTTP GET Example");
    // website url
    string url = "google.com"; // "www.google.com";

    // HTTP GET
    string get_http = "GET / HTTP/1.1\r\nHost: " + url + "\r\nConnection: close\r\n\r\n";

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        cout << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    hostent* host = gethostbyname(url.c_str()); // https://docs.microsoft.com/en-us/windows/win32/api/winsock2/nf-winsock2-gethostbyname

    SOCKADDR_IN SockAddr;
    SockAddr.sin_port = htons(80);
    SockAddr.sin_family = AF_INET;
    SockAddr.sin_addr.s_addr = *((unsigned long*)host->h_addr);

    if (connect(Socket, (SOCKADDR*)(&SockAddr), sizeof(SockAddr)) != 0) {
        cout << "Could not connect";
        return 2;
    }

    // send GET / HTTP
    send(Socket, get_http.c_str(), strlen(get_http.c_str()), 0);

    // recieve html
    char buffer[10000];
    int nDataLength;
    string website_HTML;
    while ((nDataLength = recv(Socket, buffer, 10000, 0)) > 0) {
        int i = 0;
        while (buffer[i] >= 32 || buffer[i] == '\n' || buffer[i] == '\r') {

            website_HTML += buffer[i];
            i += 1;
        }
    }

    closesocket(Socket);
    WSACleanup();

    // display HTML source 
    cout << website_HTML;

    // pause
    cout << "\n\nPress ANY key to close.\n\n";
    cin.ignore();
    cin.get();

    return 0;
}

============================================================================================================================
    
#include <iostream>
#include <windows.h>
#pragma comment(lib, "urlmon.lib")
using namespace std;

int main()
{
	// the URL to download from
	const char* srcURL = "https://www.gismeteo.ua/weather-odessa-4982/";

	// the destination file
	const char* destFile = "C:/1/weather.txt";

	// URLDownloadToFile returns S_OK on success
	if (S_OK == URLDownloadToFileA(NULL, srcURL, destFile, 0, NULL))
	{
		cout << "Saved to " << destFile << "\n";
	}

	FILE* f;
	fopen_s(&f, destFile, "r+"); // открываем его на чтение и запись

	char text[200];
	while (true)
	{ // пока всё не прочитаем
		fgets(text, 199, f); // считываем строку
		AnsiToOem(text, text); // переводим кодировку
		if (feof(f) == 0) // если файл ещё не закончился
			cout << text; // показать строку на экране консоли
		else
			break;
	}
}